+++
title = "About"
+++

Hello, my name is Görkem and I am a student developer for 42 school. This page is for a bonus for the project 42_inception. We had to choose a new service to install. I choosed "hugo" which allows to create easily website with an open source static website generator.