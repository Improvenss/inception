---
title: "Presentation"
date: 2023-07-13T10:46:32Z
draft: false
---

This page has been entirely designed to respond to a bonus from the school 42 inception project.

# Welcome to the 42 fitness_page 🐋

### What is **42 fitness**

42 fitness is an association of 42 school with the purpose of developing sport inside the school. 

### You want to join us?

Come every wednesday at 6:30 to 42 and you will enjoy one hour of sweating.

![Image 42 fitness](/42fitness.jpg)